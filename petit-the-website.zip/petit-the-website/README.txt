PETIT THÉ - Website
Buka index.html di browser. Folder assets berisi poster dan foto menu.
Form ulasan: isi variabel ENDPOINT di bagian script index.html dengan alamat penerima kiriman (JSON POST), misalnya layanan form seperti Formspree. Jika kosong, form mengarahkan pengunjung ke Instagram @petitthe.id.
Font dimuat dari Google Fonts, jadi butuh koneksi internet.
